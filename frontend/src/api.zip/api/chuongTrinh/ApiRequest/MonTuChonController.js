import apiClient from '../../apiConfig';

const ENDPOINT = '/api/chuong-trinh/mon-tu-chon';

export const createMonTuChon = (data) => {
  return apiClient.post(ENDPOINT, data);
};

export const updateMonTuChon = (id, data) => {
  return apiClient.put(`${ENDPOINT}/${id}`, data);
};

export const deleteMonTuChon = (id) => {
  return apiClient.delete(`${ENDPOINT}/${id}`);
};

export default {
  createMonTuChon,
  updateMonTuChon,
  deleteMonTuChon,
};
